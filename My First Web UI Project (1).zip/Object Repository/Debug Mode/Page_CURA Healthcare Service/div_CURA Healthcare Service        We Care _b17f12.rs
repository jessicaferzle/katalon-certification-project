<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_CURA Healthcare Service        We Care _b17f12</name>
   <tag></tag>
   <elementGuidId>0b37d663-6bb3-47b0-8573-dee8bc862fd1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text-vertical-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='top']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;CURA Healthcare Service We Care About Your Health Make Appointment&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bd18d496-b4b2-45ac-b476-3d8b4f72a254</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-vertical-center</value>
      <webElementGuid>f725b120-7664-45d6-a3d2-fd4b55a9052d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    </value>
      <webElementGuid>75bb76b5-c40c-4aea-8a41-a06a5d18c867</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;top&quot;)/div[@class=&quot;text-vertical-center&quot;]</value>
      <webElementGuid>505d61b9-a41c-4173-93cb-1549ba95d292</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='top']/div</value>
      <webElementGuid>4dd6ff57-3156-4c15-9fb9-9b0a300a6866</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::div[1]</value>
      <webElementGuid>219570c0-e15b-4b4f-843d-fc21ee8e524a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::div[1]</value>
      <webElementGuid>ff8af430-a452-4081-b486-6e9ba3ce6d7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
      <webElementGuid>6e77e19a-76c8-4b55-9de1-3e56d856f150</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ' or . = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ')]</value>
      <webElementGuid>6bd818ed-68a6-4285-af83-09d74ab17042</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
