<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Products - ViewCartButton</name>
   <tag></tag>
   <elementGuidId>5c77f3a3-3692-41dd-88d5-4b26cd75a7f1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>/html/body/section[2]/div/div/div[2]/div/div[1]/div/div/div[2]/p[2]/a/u</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
