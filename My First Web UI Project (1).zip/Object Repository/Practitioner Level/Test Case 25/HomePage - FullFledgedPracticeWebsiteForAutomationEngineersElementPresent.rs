<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>HomePage - FullFledgedPracticeWebsiteForAutomationEngineersElementPresent</name>
   <tag></tag>
   <elementGuidId>0636dda1-8e43-4b05-8f84-318d4c44d798</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>/html/body/section[1]/div/div/div/div[1]/div/div[1]/div[1]/h2</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
