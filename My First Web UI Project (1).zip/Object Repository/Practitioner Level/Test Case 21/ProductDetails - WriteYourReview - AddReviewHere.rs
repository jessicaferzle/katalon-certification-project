<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProductDetails - WriteYourReview - AddReviewHere</name>
   <tag></tag>
   <elementGuidId>977403c0-3281-4b7f-9ff4-05b928eb6a9b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>/html/body/section/div/div/div[2]/div[3]/div[2]/div/div/form/textarea</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
