
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String



def static "example.VerifyLoginSuccess.LoginSucess"() {
    (new example.VerifyLoginSuccess()).LoginSucess()
}


def static "example.FillAppointmentForm.AppointmentForm"() {
    (new example.FillAppointmentForm()).AppointmentForm()
}


def static "example.VerifyAppointmentConfirmation.AppointmentConfirmation"() {
    (new example.VerifyAppointmentConfirmation()).AppointmentConfirmation()
}


def static "example.MyKeywords.AppLogin"() {
    (new example.MyKeywords()).AppLogin()
}


def static "example.MyKeywords.Congrats"(
    	String User	) {
    (new example.MyKeywords()).Congrats(
        	User)
}


def static "example.MakeAppointmentButton.AppointmentButton"() {
    (new example.MakeAppointmentButton()).AppointmentButton()
}


def static "example.CloseBrowser.ClosetheBrowser"() {
    (new example.CloseBrowser()).ClosetheBrowser()
}


def static "example.LoginWithValidCredentials.ValidCredentials"() {
    (new example.LoginWithValidCredentials()).ValidCredentials()
}


def static "example.launchsiteOpenBrowserAndNavigate.openSite"() {
    (new example.launchsiteOpenBrowserAndNavigate()).openSite()
}


def static "example.SubmitAppointment.SubmitAppointment1"() {
    (new example.SubmitAppointment()).SubmitAppointment1()
}


def static "example.GoToHomepage.Homepage"() {
    (new example.GoToHomepage()).Homepage()
}
